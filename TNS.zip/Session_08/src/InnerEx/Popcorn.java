package InnerEx;

public abstract class Popcorn {

	public abstract void taste();
}
