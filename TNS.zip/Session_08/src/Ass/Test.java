package Ass;

public class Test {
	public static void main(String[] args) {
        Factorial f = new Factorial(5); 
        f.process(); 
        f.showData();
    }
}
