
public class C {

	public C() {
		System.out.println("Parent Default");
	}
	public C(int a) {
		System.out.println("Parameterized Constructor");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
