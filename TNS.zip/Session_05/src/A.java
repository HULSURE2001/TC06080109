
public class A {
	final int a;
	A(){
		a = 10;
	}
	public final void getA() {
		System.out.println("Number a :" + a);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
