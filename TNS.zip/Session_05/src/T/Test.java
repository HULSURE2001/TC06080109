package T;

public class Test {
	public static void main(String[] args) {
		Teacher t = new Teacher(1, "Vishal", "IT");
		t.getData();
	}

}
