
public class B extends A{
	public void get() {
		System.out.println("This is class C");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B b = new B();
		b.get();
		
	}

}
