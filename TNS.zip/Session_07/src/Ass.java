
public class Ass {

}
