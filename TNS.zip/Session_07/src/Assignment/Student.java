package Assignment;

public class Student {

}
