
public class A {
	private int no = 10;
	
	public void getNo() {
		System.out.println("No = "+ no);

	}
	public void m1() {
		System.out.println("I am m1 of A");
	}
}
public class B extends A{
	public void m1() {
		System.out.println("I am m1 of B");
	}
	public void m2() {
		System.out.println("I am m2 of B");
	}
	
	public static void main(String[] args) {
		B b = new B();
		b.m1();
		
		A b1 = new B();
		b1.m1();
	}
}
