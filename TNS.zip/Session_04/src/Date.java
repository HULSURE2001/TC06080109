
/*
public class Date {
	
	private int d,m,y;
	public Date() {
		
	}
	
	public Date(int d, int m, int y) {
		this.d = d;
		this.m = m;
		this.y = y;
	}
	
	public String toString() {
		return "Date [d = " + d + ", m=" + m + ", y=" + y + "]";
	}
	public static void swapDates(Date d1, Date d2) {
		Date tmp;
		tmp = d1;
		d1 = d2;
		d2 = tmp;
		
		System.out.println("In Method...");
		System.out.println("D1 : " +d1);
		System.out.println("D2 : " +d2);
	}
	public static void main(String[] args) {
		Date d1 = new Date(20,10,2023);
		Date d2 = new Date(22,10,2023);
		
		System.out.println("Before Sawaping...");
		System.out.println("D1 : " +d1);
		System.out.println("D2 : " +d2);
		
		Date.swapDates(d1, d2);
		System.out.println("After Sawaping...");
		System.out.println("D1 : " +d1);
		System.out.println("D2 : " +d2);
		
	}
}
*/


public class Date {
	
	private int d,m,y;
	public Date() {
		
	}
	
	public Date(int d, int m, int y) {
		this.d = d;
		this.m = m;
		this.y = y;
	}
	
	public String toString() {
		return "Date [d = " + d + ", m=" + m + ", y=" + y + "]";
	}
	public static void swapDates(Date d[]) {
		Date tmp = d[0];
		d[0] = d[1];
		d[1] = tmp;
		
		
	}
	public static void main(String[] args) {
		Date[] d = new Date[2];
		d[0] = new Date(20,10,2023);
		d[1] = new Date(22,10,2023);
		
		System.out.println("Before Sawaping...");
		System.out.println("D1 : " + d[0]);
		System.out.println("D2 : " + d[1]);
		
		Date.swapDates(d);
		System.out.println("After Sawaping...");
		System.out.println("D1 : " +d[0]);
		System.out.println("D2 : " +d[1]);
		
	}
}
