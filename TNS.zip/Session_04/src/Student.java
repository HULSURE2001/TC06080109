import java.util.*;

public class Student {
    private int rollNo;
    private String name;
    private int m1, m2, m3;

    public Student() {
    }

    public Student(int rollNo, String name, int m1, int m2, int m3) {
        this.rollNo = rollNo;
        this.name = name;
        this.m1 = m1;
        this.m2 = m2;
        this.m3 = m3;
    }

    public void getData(Student arr[], int size) {
        for (int i = 0; i < size; i++) {
            System.out.println("Roll No : " + arr[i].getRollNo());
            System.out.println("Name : " + arr[i].getName());
            System.out.println("M1 : " + arr[i].getM1());
            System.out.println("M2 : " + arr[i].getM2());
            System.out.println("M3 : " + arr[i].getM3());
        }
    }

    public int getRollNo() {
        return rollNo;
    }

    public String getName() {
        return name;
    }

    public int getM1() {
        return m1;
    }

    public int getM2() {
        return m2;
    }

    public int getM3() {
        return m3;
    }

    public static void main(String[] args) {
        int n;
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        Student arr[] = new Student[n];

        for (int i = 0; i < n; i++) {
            arr[i] = new Student(); // Initialize each Student object

            arr[i].rollNo = sc.nextInt();
            arr[i].name = sc.next();
            arr[i].m1 = sc.nextInt();
            arr[i].m2 = sc.nextInt();
            arr[i].m3 = sc.nextInt();
        }

        Student s = new Student();
        s.getData(arr, n);
    }
}
