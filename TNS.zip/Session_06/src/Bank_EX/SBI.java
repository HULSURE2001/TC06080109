package Bank_EX;

public class SBI extends Bank{
	

	@Override
	public float getROI() {
		// TODO Auto-generated method stub
		return 0;
	}

}
