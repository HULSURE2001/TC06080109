package Bank_EX;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bank b = new BOI();
		System.out.println("BOI = " + b.getROI());
		
	}

}
