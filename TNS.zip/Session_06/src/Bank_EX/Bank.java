package Bank_EX;

public abstract class Bank {
	
	public abstract float getROI();
	
	public void get() {
		System.out.println("Hello");
	}

	
}
