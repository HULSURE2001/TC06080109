package Bank_EX;

public class BOI extends Bank{
	
	public float getROT() {
		return 6.5f;
	}

	@Override
	public float getROI() {
		// TODO Auto-generated method stub
		return 0;
	}

}
