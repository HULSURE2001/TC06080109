package Interface_EX;

public interface ArithCal {
	int no = 100;
	
	public int add(int a, int b);
	public int sub(int a, int b);

}
