package Interface_EX;

public class Test {
	public static void main(String[] args) {
		Calculations c = new Calculations();
		
		System.out.println("Addition is -> " + c.add(14, 12));
		System.out.println("Addition is -> " + c.sub(14, 12));
		System.out.println("Addition is -> " + c.fact(5));
		System.out.println("Addition is -> " + c.avg(14, 12));
	}
}
