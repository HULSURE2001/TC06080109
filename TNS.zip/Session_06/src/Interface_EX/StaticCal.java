package Interface_EX;

public interface StaticCal extends ArithCal{
	
	public int avg(int a, int b);

}
