package Shapes_EX;

public abstract class Shape {
	public abstract double area();
}
