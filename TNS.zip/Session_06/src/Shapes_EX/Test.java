package Shapes_EX;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape s = new Circle(5);
		System.out.println("Area of Circle " + s.area());
	}

}
