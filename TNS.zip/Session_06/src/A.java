
public class A{
	A get() {
		return this;
	}
}